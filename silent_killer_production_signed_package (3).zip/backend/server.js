// Simple Node.js Express stub for file upload and process job creation.
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const upload = multer({ dest: 'uploads/' });
const app = express();
app.use(express.json());

app.post('/upload', upload.single('file'), (req, res) => {
  // In production: push job to queue, start OCR + summarization, return jobId
  if (!req.file) return res.status(400).json({ error: 'file required' });
  const filePath = path.resolve(req.file.path);
  // For demo, just return fake note after delay
  setTimeout(() => {
    res.json({ status: 'done', note: { summary: 'यह एक डेमो संक्षेप है', bullets: ['बिंदु 1','बिंदु 2'] } });
  }, 2000);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend stub running on ${PORT}`));
