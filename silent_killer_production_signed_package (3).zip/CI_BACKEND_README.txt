CI & Backend Usage

- Push the flutter_starter folder to a GitHub repository on the 'main' branch.
- The included GitHub Actions workflow (.github/workflows/flutter_build.yml) will build a release APK automatically.
- After the workflow completes, download the APK from the workflow artifacts.

Backend stub:
- The backend folder contains a simple Node.js express app that accepts file uploads at /upload
- For production, replace stub logic with actual OCR (Google Vision) + summarization pipeline and a job queue.
- To run locally:
    cd backend
    npm install
    node server.js
