// Placeholder for API service - integrate OCR and AI endpoints here.
import 'dart:io';
class ApiService {
  // Example: upload file and trigger processing
  Future<Map<String,dynamic>> uploadFile(File file) async {
    // Implement multipart upload to your backend (S3 presigned or API)
    return {'status': 'ok', 'docId': 'demo123'};
  }
}
