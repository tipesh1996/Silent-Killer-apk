import 'package:flutter/material.dart';

class PreviewScreen extends StatelessWidget {
  final String? filePath;
  const PreviewScreen({Key? key, this.filePath}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Generated Note'), backgroundColor: Colors.transparent, foregroundColor: Color(0xFF0B1A2B)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text('Summary', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 8),
            Text('यहाँ पर डॉक्युमेंट का संक्षेप (1-2 पंक्तियाँ) दिखेगा...'),
            SizedBox(height: 16),
            Text('Key Points', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            SizedBox(height: 8),
            Text('• मुख्य बिंदु 1\n• मुख्य बिंदु 2\n• मुख्य बिंदु 3'),
            SizedBox(height: 16),
            Text('Notebook View', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            SizedBox(height: 8),
            Container(
              height: 400,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Color(0xFFEAF4FF))
              ),
              child: Center(child: Text('(Handwriting-style notebook preview)')),
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.download),
              label: Text('Export as PDF'),
              onPressed: () {
                // Hook up export generation
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Export not implemented in starter.')));
              },
            )
          ],
        ),
      ),
    );
  }
}
