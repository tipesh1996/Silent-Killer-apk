import 'package:flutter/material.dart';
import 'upload_screen.dart';
import 'preview_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Silent Killer'),
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Color(0xFF0B1A2B),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 8),
            Text('AI Note Creator', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            ElevatedButton.icon(
              icon: Icon(Icons.upload_file),
              label: Text('Upload PDF'),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => UploadScreen()));
              },
            ),
            SizedBox(height: 20),
            Text('Recent Notes', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            SizedBox(height: 12),
            Card(
              child: ListTile(
                title: Text('Sample: Physics - Thermodynamics'),
                subtitle: Text('Generated note • 3 pages'),
                trailing: IconButton(
                  icon: Icon(Icons.open_in_new),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => PreviewScreen()));
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
