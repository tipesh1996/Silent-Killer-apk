import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'preview_screen.dart';

class UploadScreen extends StatefulWidget {
  @override
  _UploadScreenState createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  String? _filePath;
  bool _processing = false;

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    if (result != null && result.files.single.path != null) {
      setState(() {
        _filePath = result.files.single.path;
        _processing = true;
      });
      // Simulate processing / upload
      await Future.delayed(Duration(seconds: 2));
      setState(() {
        _processing = false;
      });
      Navigator.push(context, MaterialPageRoute(builder: (_) => PreviewScreen(filePath: _filePath)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Upload PDF'), backgroundColor: Colors.transparent, foregroundColor: Color(0xFF0B1A2B)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Choose a PDF to generate notes', style: TextStyle(fontSize: 16)),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.attach_file),
              label: Text('Select PDF'),
              onPressed: _pickFile,
            ),
            if (_processing) ...[
              SizedBox(height: 20),
              LinearProgressIndicator(),
              SizedBox(height: 8),
              Text('Processing (simulated)...'),
            ]
          ],
        ),
      ),
    );
  }
}
