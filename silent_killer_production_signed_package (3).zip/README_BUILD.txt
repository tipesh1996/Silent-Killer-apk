BUILD & RUN INSTRUCTIONS - Silent Killer (Flutter Starter)
---------------------------------------------------------
Prerequisites:
- Install Flutter SDK: https://flutter.dev/docs/get-started/install
- For Android: install Android Studio + Android SDK + set ANDROID_HOME
- For iOS: Xcode (macOS)
- Optional: install VS Code with Flutter extension

Steps:
1) Unzip the flutter_starter folder or open it in your IDE.
2) From command line, run:
   flutter pub get
   flutter run  (to run on connected device/emulator)
3) To build APK:
   flutter build apk --release
   The built APK will be in build/app/outputs/flutter-apk/app-release.apk

Notes:
- The starter demonstrates UI & file-picking flow only; integrate cloud OCR (Google Vision / ML Kit),
  LLM summarization (OpenAI or self-hosted HF models) and backend for full functionality.
- For best PDF rendering performance, use pdf_render and render pages lazily.
- For large PDF files, process server-side (stream pages) and show incremental progress via WebSocket.
